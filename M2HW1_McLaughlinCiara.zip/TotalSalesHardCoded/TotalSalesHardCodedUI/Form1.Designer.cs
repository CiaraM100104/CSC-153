﻿
using System;

namespace TotalSalesHardCodedUI
{
    partial class TotalSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.salesListBox1 = new System.Windows.Forms.ListBox();
            this.Totallabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // salesListBox1
            // 
            this.salesListBox1.FormattingEnabled = true;
            this.salesListBox1.Location = new System.Drawing.Point(21, 12);
            this.salesListBox1.Name = "salesListBox1";
            this.salesListBox1.Size = new System.Drawing.Size(231, 160);
            this.salesListBox1.TabIndex = 0;
            this.salesListBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Totallabel
            // 
            this.Totallabel.AutoSize = true;
            this.Totallabel.Location = new System.Drawing.Point(109, 192);
            this.Totallabel.Name = "Totallabel";
            this.Totallabel.Size = new System.Drawing.Size(31, 13);
            this.Totallabel.TabIndex = 1;
            this.Totallabel.Text = "Total";
            // 
            // TotalSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(264, 227);
            this.Controls.Add(this.Totallabel);
            this.Controls.Add(this.salesListBox1);
            this.Name = "TotalSales";
            this.Text = "Total Sales";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.ListBox salesListBox1;
        private System.Windows.Forms.Label Totallabel;
    }
}

