﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 1/30/2021
* CSC 153
* Ciara McLaughlin
* This program will display an array of numbers, then display the total.
*/


namespace TotalSalesHardCodedUI
{
    public partial class TotalSales : Form
    {
        public TotalSales()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            const int SIZE = 7;
            int index = 0;
            decimal total = 0;

            decimal[] sales = new decimal[SIZE];

            StreamReader inputFile = File.OpenText("Sales.txt");

            while (!inputFile.EndOfStream && index < sales.Length)
            {
                sales[index] = decimal.Parse(inputFile.ReadLine());
                index++;
            }

            foreach (decimal val in sales)
            {
                salesListBox1.Items.Add(val.ToString("c"));
            }

            foreach (decimal val in sales)
            {
                total += val;
                Totallabel.Text = total.ToString("c");
            }

            




        }

        }
    }

