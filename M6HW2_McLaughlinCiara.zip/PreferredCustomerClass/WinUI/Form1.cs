﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PreferredCustomerClassLibrary;

/**
* 5/8/2022
* CSC 153
* Ciara McLaughlin
* This program displays a customers information including their discount.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool mailingAdd = Boolean.Parse(mailingListBox.Text);
            double userDouble = Convert.ToDouble(amountBox.Text);


            PreferredCustomer userCustomer = new PreferredCustomer(nameBox.Text, addressBox.Text, telephoneBox.Text, customerNumBox.Text, mailingAdd, userDouble);


            userInfoBox.Items.Add(userCustomer.name);
            userInfoBox.Items.Add(userCustomer.address);
            userInfoBox.Items.Add(userCustomer.phoneNumber);
            userInfoBox.Items.Add(userCustomer.customerNumber);
            userInfoBox.Items.Add(userCustomer.spentAmount);
            userInfoBox.Items.Add("Your discount is " + userCustomer.discount + " percent off.");


            if (mailingAdd == true)
            {
                userInfoBox.Items.Add("Mailing List? Yes");
            }

            if (mailingAdd == false)
            {
                userInfoBox.Items.Add("Mailing List? No");
            }
        }
    }
}
