﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class PreferredCustomer : Customer
    {
        private double _spentAmount;
        private double _discount;

        public PreferredCustomer(string name, string address, string phone, string customerNumber, bool mailing, double spentAmount)
            : base(name, address, phone, customerNumber, mailing)
        {

            _spentAmount = spentAmount;
        }

        public static double getDiscount(double spentAmount)
        {
            if (spentAmount == 500)
            {
                return (5);
            }
            else if (spentAmount == 1000)
            {
                return (6);
            }
            else if (spentAmount == 1500)
            {
                return (7);
            }
            else if (spentAmount >= 2000)
            {
                return (10);
            }
            else
            {
                return (0);
            }
        }

        public double spentAmount
        {
            get { return _spentAmount; }
            set { }
        }

        public double discount
        {
            get { return getDiscount(spentAmount); }
            set { }
        }


    }
}
