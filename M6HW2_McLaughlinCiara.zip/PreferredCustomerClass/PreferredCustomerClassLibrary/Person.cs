﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class Person
    {
        private string _name;
        private string _address;
        private string _phoneNumber;

        public Person()
        {
            _name = "";
            _address = "";
            _phoneNumber = "";
        }

        public Person(string name, string address, string phoneNumber)
        {
            _name = name;
            _address = address;
            _phoneNumber = phoneNumber;
        }

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string address
        {
            get { return _address; }
            set { }
        }

        public string phoneNumber
        {
            get { return _phoneNumber; }
            set { }
        }
    }
}
