﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 2/20/2022
* CSC 153
* Ciara McLaughlin
* This program creates a file that generates a certain amount of numbers from 1-100 based on the users input
*/

namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fileButton_Click(object sender, EventArgs e)
        {
            try
            {

            
            int number = int.Parse(numTextBox.Text.ToString());
            int randomNumber = 0;

            StreamWriter outputFile;
            SaveFileDialog saveFileDialog = new SaveFileDialog();

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    outputFile = File.CreateText("Number.txt");
                    Random rand = new Random();

                    for (int count = 0; count < number; count++)
                    {
                        randomNumber = rand.Next(1, 101);
                        outputFile.WriteLine(randomNumber);
                    }

                    outputFile.Close();
                }
                else
                {
                    MessageBox.Show("Cancelled.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
