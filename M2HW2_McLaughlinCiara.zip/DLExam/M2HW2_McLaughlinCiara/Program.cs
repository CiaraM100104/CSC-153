﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2HW2_McLaughlinCiara
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
