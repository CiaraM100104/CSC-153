﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/**
* 2/8/2022
* CSC 153
* Ciara McLaughlin
* This program should allow people to submit a drivers test and see their incorrect answers.
*/

namespace DriversLicenseExam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] answerArray = { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };
            string[] studentAnsArray = new string[20];

            List<string> incorrectList = new List<string>();

            int count = 0, index = 0, qnumber = 0;

            {
                StreamReader inputFile;

                inputFile = File.OpenText("Driverslicense.txt");
                studentAnsArray[index] = inputFile.ReadLine();

                if (studentAnsArray[index] == answerArray[index])
                    count++;
                else
                {
                    qnumber = index + 1;
                    incorrectList.Add(qnumber.ToString());
                }
                index++;
            }
            
            if (count >= 15)
            {
                label2.Text = "Congratulations, you've passed!";
            }
            else
            {
                label2.Text = "Unfortunately, you've failed.";
            }
            foreach (string str in incorrectList)
            {
                listBox1.Items.Add(str);
            }
 
    }

    private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

    }
}
