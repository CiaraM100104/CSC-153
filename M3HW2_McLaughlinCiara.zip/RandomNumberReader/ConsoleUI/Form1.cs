﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
* 2/27/2022
* CSC 153
* Ciara McLaughlin
* This program will read numbers from the previous program and count them up and add them.
*/

namespace ConsoleUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void readFile_Click(object sender, EventArgs e)
        {
            try
            {
                int number = 0;
                int total = 0;
                int count = 0;

                OpenFileDialog loadFile = new OpenFileDialog();
                loadFile.ShowDialog();
                string path = loadFile.FileName;

                StreamReader inputFile = File.OpenText(path);

                while (!inputFile.EndOfStream)
                {
                    number = int.Parse(inputFile.ReadLine());
                    count = count + 1;
                    total = number + total;
                    displayBox.Items.Add(count + " " + number + " " + total);
                }

                inputFile.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); 
            }
        }
    }
}
