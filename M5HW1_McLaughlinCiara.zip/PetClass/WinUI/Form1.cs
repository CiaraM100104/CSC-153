﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

/**
* 4/3/2022
* CSC 153
* Ciara McLaughlin
* This program has a user input values that are stored in objects and then displayed.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayText_Click(object sender, EventArgs e)
        {
            Pet myPet = new Pet();

            myPet.Name = nameInput.Text;
            myPet.Type = typeInput.Text;
            myPet.Age = int.Parse(ageInput.Text);

            nameOutput.Text = myPet.Name;
            typeOutput.Text = myPet.Type;
            ageOutput.Text = myPet.Age.ToString();


        }
    }
}
