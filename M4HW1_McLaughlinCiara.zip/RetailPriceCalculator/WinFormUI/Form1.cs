﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceCalculatorLibrary;

/**
* 3/6/2022
* CSC 153
* Ciara McLaughlin
* This program will calculate retail price based on the user's input.
*/

namespace WinFormUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcRetail_Click(object sender, EventArgs e)
        {
            double markup;
            double wholesale;

            if (double.TryParse(wholesaleTxtBox.Text, out wholesale) && double.TryParse(markupTxtBox.Text, out markup))
            {
                double retailPrice;
                retailPrice = RetailCalculator.CalculateRetail(ref markup, wholesale);
                retailTxtBox.Text = retailPrice.ToString("C");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers", "Invalid Input");
            }
        }
    }
}
