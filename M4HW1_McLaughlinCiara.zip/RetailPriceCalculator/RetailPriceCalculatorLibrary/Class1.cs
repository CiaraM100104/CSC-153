﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceCalculatorLibrary
{
    public static class RetailCalculator
    {

        public static double CalculateRetail(ref double x, double y)
        {
            double markupPercent = x / 100;
            double retailPrice;

            retailPrice = y + (y * markupPercent);
            return retailPrice;
        }
    }
}
