﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonAndCustomerClassLibrary;

/**
* 5/1/2022
* CSC 153
* Ciara McLaughlin
* This program will take data regarding a customer and display it back.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            bool mailingAdd = Boolean.Parse(mailingListBox.Text);
            

            Customer userCustomer = new Customer(nameBox.Text, addressBox.Text, telephoneBox.Text, customerNumBox.Text, mailingAdd);


            userInfoBox.Items.Add(userCustomer.name);
            userInfoBox.Items.Add(userCustomer.address);
            userInfoBox.Items.Add(userCustomer.phoneNumber);
            userInfoBox.Items.Add(userCustomer.customerNumber);

            if (mailingAdd == true)
            {
                userInfoBox.Items.Add("Mailing List? Yes");
            }

            if (mailingAdd == false)
            {
                userInfoBox.Items.Add("Mailing List? No");
            }
        }
    }
}
