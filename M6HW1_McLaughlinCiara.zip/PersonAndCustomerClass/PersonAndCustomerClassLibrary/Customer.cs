﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonAndCustomerClassLibrary
{
    public class Customer : Person
    {
        private string _customerNumber;
        private bool _mailingList;

        public Customer(string name)
        {

        }

        public Customer(string name, string address, string phone, string customerNumber, bool mailing)
            : base(name, address, phone)
        {
            _customerNumber = customerNumber;
            _mailingList = mailing = true;
        }

        public string customerNumber
        {
            get { return _customerNumber; }
            set { }
        }

        public bool MailingList
        {
            get { return _mailingList; }
            set { }
        }
    }
}
