﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingDistanceLib
{
    public class Class1
    {
        public static double CalculateDistance (ref double x)
        {
            double g = 9.8;
            double distanceAmount = 0.5 * g * Math.Pow(x, 2);
            return distanceAmount;
        }
    }
}
