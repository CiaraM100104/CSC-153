﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingDistanceLib;

/**
* 3/13/2022
* CSC 153
* Ciara McLaughlin
* This program will calculate distance based in the time a user enters.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void distanceCalc_Click(object sender, EventArgs e)
        {
            double timeAmount;
            if (double.TryParse(timeTxtBox.Text, out timeAmount))
            {
                double distanceAmount;
                distanceAmount = Class1.CalculateDistance(ref timeAmount);
                distanceTxtBox.Text = distanceAmount.ToString("n") + " meters";
            }
            else
            {
                MessageBox.Show("Please enter valid numbers", "Invalid Input");
            }
        }
    }
}
