﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timeTxtBox = new System.Windows.Forms.TextBox();
            this.distanceTxtBox = new System.Windows.Forms.TextBox();
            this.distanceCalc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Distance";
            // 
            // timeTxtBox
            // 
            this.timeTxtBox.Location = new System.Drawing.Point(117, 36);
            this.timeTxtBox.Name = "timeTxtBox";
            this.timeTxtBox.Size = new System.Drawing.Size(100, 20);
            this.timeTxtBox.TabIndex = 2;
            // 
            // distanceTxtBox
            // 
            this.distanceTxtBox.Location = new System.Drawing.Point(117, 70);
            this.distanceTxtBox.Name = "distanceTxtBox";
            this.distanceTxtBox.Size = new System.Drawing.Size(100, 20);
            this.distanceTxtBox.TabIndex = 3;
            // 
            // distanceCalc
            // 
            this.distanceCalc.Location = new System.Drawing.Point(117, 115);
            this.distanceCalc.Name = "distanceCalc";
            this.distanceCalc.Size = new System.Drawing.Size(75, 23);
            this.distanceCalc.TabIndex = 4;
            this.distanceCalc.Text = "Calculate";
            this.distanceCalc.UseVisualStyleBackColor = true;
            this.distanceCalc.Click += new System.EventHandler(this.distanceCalc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 204);
            this.Controls.Add(this.distanceCalc);
            this.Controls.Add(this.distanceTxtBox);
            this.Controls.Add(this.timeTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox timeTxtBox;
        private System.Windows.Forms.TextBox distanceTxtBox;
        private System.Windows.Forms.Button distanceCalc;
    }
}

